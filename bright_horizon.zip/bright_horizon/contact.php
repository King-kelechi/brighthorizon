<?php
    include 'inc/header.php';
?>
<!-- Header -->
 <header id="header" class="ex-header">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1>Contact Us.</h1>
            </div> <!-- end of col -->
        </div> <!-- end of row -->
    </div> <!-- end of container -->
</header> <!-- end of ex-header -->
<!-- end of header -->


<!-- Breadcrumbs -->
<div class="ex-basic-1">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="breadcrumbs">
                    <a href="index.php">Home</a><i class="fa fa-angle-double-right"></i><span>Creating a new world</span>
                </div> <!-- end of breadcrumbs -->
            </div> <!-- end of col -->
        </div> <!-- end of row -->
    </div> <!-- end of container -->
</div> <!-- end of ex-basic-1 -->
<!-- end of breadcrumbs -->


<!-- Privacy Content -->
<div class="ex-basic-2">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="text-container">
                    <h3>Bright Horizons Inc.</h3>
                    <p>Welcome to Bright Horizons Inc., where compassion meets commitment in providing unparalleled care for children and adults navigating the intricate journey of developmental and learning disabilities, as well as mental health challenges. Nestled within the warm embrace of our residential settings, we cultivate a sanctuary of understanding, growth, and empowerment.

                        At Bright Horizons Inc., our dedicated team of caregivers is driven by a shared vision – to illuminate the path towards brighter tomorrows. With unwavering devotion, we specialize in creating tailored environments that foster holistic well-being, embracing the unique qualities of each individual under our care.</p>
                
                <div class="text-container">
                    <div class="row">
                        <div class="col-md-6">
                            <br><br>
                            <h3>You can Contact us Directly</h3>
                            <h5>Address:</h5>
                            <p>27 Galtee Road Brampton Ontario L6XOJ5</p>
                            <h5>Email:</h5>
                            <p>info@brighthorizonsgrh.ca</p>
                            
                        </div> <!-- end of col -->
                        <div class="col-md-6">
                            <div style="text-decoration:none; overflow:hidden;max-width:100%;width:100%;height:400px;"><div id="g-mapdisplay" style="height:100%; width:100%;max-width:100%;"><iframe style="height:100%;width:100%;border:0;" frameborder="0" src="https://www.google.com/maps/embed/v1/place?q=27+Galtee+Road,+Brampton,+Ontario,+Canada&key=AIzaSyBFw0Qbyq9zTFTd-tUY6dZWTgaQzuU17R8"></iframe></div><a class="google-maps-html" rel="nofollow" href="https://www.bootstrapskins.com/themes" id="inject-map-data">premium bootstrap themes</a><style>#g-mapdisplay img{max-width:none!important;background:none!important;font-size: inherit;font-weight:inherit;}</style></div>
                            
                        </div> <!-- end of col -->
                    </div> <!-- end of row -->
                </div> <!-- end of text-container -->

                <div class="text-container dark">
                    <p class="testimonial-text">At Bright Horizon Inc., we envision a world where individuals with developmental/learning disabilities and mental illness thrive in a supportive and nurturing environment, unlocking their full potential and leading fulfilling lives. Our commitment is to be a beacon of hope, fostering inclusive communities that empower every individual to overcome challenges and embrace a future filled with possibilities.</p>
                </div> <!-- end of text container -->

                <div class="text-container last">
                    <h3>Mission statement</h3>
                    <p>Bright Horizon Inc. is dedicated to providing exceptional care and support for children and adults with developmental/learning disabilities and mental illness within a residential setting. Our mission is to create a compassionate and enriching living environment that promotes independence, self-discovery, and overall well-being.</p>
                </div> <!-- end of text-container -->
                <a class="btn-outline-reg" href="index.php">BACK</a>
            </div> <!-- end of col-->
        </div> <!-- end of row -->
    </div> <!-- end of container -->
</div> <!-- end of ex-basic-2 -->
<!-- end of privacy content -->


<!-- Breadcrumbs -->
<div class="ex-basic-1">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="breadcrumbs">
                    <a href="index.php">Home</a><i class="fa fa-angle-double-right"></i><span>Bright Horizons Inc.</span>
                </div> <!-- end of breadcrumbs -->
            </div> <!-- end of col -->
        </div> <!-- end of row -->
    </div> <!-- end of container -->
</div> <!-- end of ex-basic-1 -->
<!-- end of breadcrumbs -->

<?php
    include 'inc/footer.php';
?>

<?php
// Define your database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bhDB";

// Create a connection to the database
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// If the form is submitted
if(isset($_POST['submit'])){
    // Collect form data
    $semail = $_POST["semail"];
    $sname = $_POST["sname"];
    $sphone = $_POST["sphone"];
    $spur = $_POST["spur"];
    $sterms = $_POST["sterms"];
    // Add more fields as needed

    // Insert data into the database
    $sql = "INSERT INTO registration_data (semail, sname, sphone, spur, sterms) VALUES ('$semail', '$sname', '$sphone', '$spur', '$sterms')";
    // Add more fields as needed

    if ($conn->query($sql) === TRUE) {
        $message = "This is an alert message.";
        echo "<script>alert('$message');</script>";
        header("location:confirmation.php");
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close the database connection
$conn->close();
?>
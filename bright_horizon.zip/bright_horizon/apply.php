<?php
include 'inc/header.php';
?>

  <!-- Header -->
    <header id="header" class="ex-2-header">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h1>Register Here</h1>
                   <p>Fill out the form below</p> 
                    <!-- Sign Up Form -->
                    <div class="form-container">
                        <form id="" data-toggle="validator" data-focus="false" action="reg1.php" method="post">
                            <div class="form-group">
                                <input type="email" class="form-control-input" id="semail" name="semail" required>
                                <label class="label-control" for="semail">Email</label>
                                <div class="help-block with-errors"></div>
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control-input" id="sname" name="sname" required>
                                <label class="label-control" for="sname">Name</label>
                                <div class="help-block with-errors"></div>
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control-input" id="spur" name="spur" required>
                                <label class="label-control" for="spur">Purpose of Registering</label>
                                <div class="help-block with-errors"></div>
                            </div>
                            <div class="form-group">
                                <input type="tel" class="form-control-input" id="sphone" name="sphone" required>
                                <label class="label-control" for="sphone">Phone Number</label>
                                <div class="help-block with-errors"></div>
                            </div>
                            <div class="form-group checkbox">
                                <input type="checkbox" id="sterms" value="Agreed-to-Terms" name="sterms" required>I agree with Bright Horizon Inc. 
                                <div class="help-block with-errors"></div>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="form-control-submit-button" value="submit" name="submit">REGISTER</button>
                            </div>
                            <div class="form-message">
                                    <?php if(isset($message)) { ?>
                                        <div class="message <?php echo $type; ?>"><?php echo $message; ?></div>
                                    <?php } ?>
                                <div id="smsgSubmit" class="h3 text-center hidden"></div>
                            </div>
                        </form>
                    </div> <!-- end of form container -->
                    <!-- end of sign up form -->
                        <br><br><br>
                </div> <!-- end of col -->
            </div> <!-- end of row -->
        </div> <!-- end of container -->
    </header> <!-- end of ex-header -->
    <!-- end of header -->
 <!-- Breadcrumbs -->

  <!-- Scripts -->
  <script src="js/jquery.min.js"></script> <!-- jQuery for Bootstrap's JavaScript plugins -->
  <script src="js/popper.min.js"></script> <!-- Popper tooltip library for Bootstrap -->
  <script src="js/bootstrap.min.js"></script> <!-- Bootstrap framework -->
  <script src="js/jquery.easing.min.js"></script> <!-- jQuery Easing for smooth scrolling between anchors -->
  <script src="js/swiper.min.js"></script> <!-- Swiper for image and text sliders -->
  <script src="js/jquery.magnific-popup.js"></script> <!-- Magnific Popup for lightboxes -->
  <script src="js/validator.min.js"></script> <!-- Validator.js - Bootstrap plugin that validates forms -->
  <script src="js/scripts.js"></script> <!-- Custom scripts -->
</body>
</html>
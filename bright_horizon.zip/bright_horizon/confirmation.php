<?php
include 'inc/header.php';
?>

 <!-- Header -->
 <header id="header" class="ex-header">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h1>Confirmation</h1>
                </div> <!-- end of col -->
            </div> <!-- end of row -->
        </div> <!-- end of container -->
    </header> <!-- end of ex-header -->
    <!-- end of header -->


    <!-- Breadcrumbs -->
    <div class="ex-basic-1">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumbs">
                        <a href="index.php">Home</a><i class="fa fa-angle-double-right"></i><span>Confirming your application</span>
                    </div> <!-- end of breadcrumbs -->
                </div> <!-- end of col -->
            </div> <!-- end of row -->
        </div> <!-- end of container -->
    </div> <!-- end of ex-basic-1 -->
    <!-- end of breadcrumbs -->


    <!-- Terms Content -->
    <div class="ex-basic-2">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="text-container">
                        <h3>Application Confirmation</h3>
                        <p>From Bright Horizon Inc.</p>
                        <p>Thank you for submitting your application to Bright Horizon Inc.! Your information has been successfully received.</p>
                        <p>We will review your application and contact you shortly with further instructions. If you have any immediate questions, please feel free to contact us at [contact number] or [email address].</p>
                    </div> <!-- end of text-container -->
                    
                    <div class="text-container last">
                        <h3>Bright Horizons Inc.</h3>
                        <p>At Bright Horizon Inc., we envision a world where individuals with developmental/learning disabilities and mental illness thrive in a supportive and nurturing environment, unlocking their full potential and leading fulfilling lives. Our commitment is to be a beacon of hope, fostering inclusive communities that empower every individual to overcome challenges and embrace a future filled with possibilities.</p>
                        <a class="btn-outline-reg" href="index.php">BACK</a>
                    </div> <!-- end of text-container -->
                </div>
            </div> <!-- end of row -->
        </div> <!-- end of container -->
    </div> <!-- end of ex-basic -->
    <!-- end of terms content -->

     <!-- Scripts -->
  <script src="js/jquery.min.js"></script> <!-- jQuery for Bootstrap's JavaScript plugins -->
  <script src="js/popper.min.js"></script> <!-- Popper tooltip library for Bootstrap -->
  <script src="js/bootstrap.min.js"></script> <!-- Bootstrap framework -->
  <script src="js/jquery.easing.min.js"></script> <!-- jQuery Easing for smooth scrolling between anchors -->
  <script src="js/swiper.min.js"></script> <!-- Swiper for image and text sliders -->
  <script src="js/jquery.magnific-popup.js"></script> <!-- Magnific Popup for lightboxes -->
  <script src="js/validator.min.js"></script> <!-- Validator.js - Bootstrap plugin that validates forms -->
  <script src="js/scripts.js"></script> <!-- Custom scripts -->
</body>
</html>
<?php
    include 'inc/header.php';
?>
<!-- Header -->
 <header id="header" class="ex-header">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1>About Bright Horizons Inc.</h1>
            </div> <!-- end of col -->
        </div> <!-- end of row -->
    </div> <!-- end of container -->
</header> <!-- end of ex-header -->
<!-- end of header -->


<!-- Breadcrumbs -->
<div class="ex-basic-1">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="breadcrumbs">
                    <a href="index.php">Home</a><i class="fa fa-angle-double-right"></i><span>creating a new world</span>
                </div> <!-- end of breadcrumbs -->
            </div> <!-- end of col -->
        </div> <!-- end of row -->
    </div> <!-- end of container -->
</div> <!-- end of ex-basic-1 -->
<!-- end of breadcrumbs -->


<!-- Privacy Content -->
<div class="ex-basic-2">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="image-container-large">
                    <img class="img-fluid" src="images/Child adult interaction.webp" alt="alternative">
                </div> <!-- end of image-container-large -->
                <div class="text-container">
                    <h3>Bright Horizons Inc.</h3>
                    <p>Welcome to Bright Horizons Inc., where compassion meets commitment in providing unparalleled care for children and adults navigating the intricate journey of developmental and learning disabilities, as well as mental health challenges. Nestled within the warm embrace of our residential settings, we cultivate a sanctuary of understanding, growth, and empowerment.

                        At Bright Horizons Inc., our dedicated team of caregivers is driven by a shared vision – to illuminate the path towards brighter tomorrows. With unwavering devotion, we specialize in creating tailored environments that foster holistic well-being, embracing the unique qualities of each individual under our care.</p>
                 <h3>Core values</h3>   
                <p>
                    <ul>
                        <li>Compassion: We approach every individual with empathy, understanding their unique needs and challenges, and providing unwavering support to enhance their quality of life.</li>
                        <li>Inclusivity: We believe in fostering an inclusive community where diversity is celebrated, and every individual is valued for their unique strengths and contributions.</li>
                        <li>Empowerment: We empower those in our care to achieve their fullest potential by promoting independence, self-determination, and the acquisition of essential life skills.</li>
                        <li>Holistic Care: We are committed to addressing the physical, emotional, and mental well-being of our residents, recognizing the interconnectedness of these elements in promoting overall health.</li>
                        <li>Continuous Growth: We strive for excellence through continuous learning, innovation, and adaptation to emerging best practices, ensuring that our services evolve to meet the evolving needs of those we serve.</li>
                        <li>Collaboration: We recognize the importance of collaboration among residents, families, caregivers, and the broader community to create a supportive network that enhances the overall care experience.</li>
                        <li>Advocacy: We advocate for the rights and dignity of individuals with developmental/learning disabilities and mental illness, working towards a society that embraces and supports their inclusion.</li>
                    </ul>     
                </p>
                <div class="text-container">
                    <div class="row">
                        <div class="col-md-6">
                            <h3>We transcend conventional care</h3>
                            <p>In our haven of compassion, we weave a tapestry of support for children and adults, offering not only a safe haven but a vibrant community where milestones are celebrated, challenges are embraced, and dreams are nurtured. Our commitment extends beyond mere assistance; it is an unspoken promise to empower every soul within our care, encouraging self-discovery and fostering a sense of belonging.

                                With a rich tapestry of therapeutic programs, educational initiatives, and personalized attention, we stand as a beacon of hope for families seeking a nurturing haven. Our expertise extends to addressing a spectrum of developmental needs and mental health challenges, ensuring that every individual entrusted to us receives the tailored care they deserve.</p>
                            
                        </div> <!-- end of col -->
                        <div class="col-md-6">
                            <div class="image-container-small">
                                <img class="img-fluid" src="images/intensive-outpatient-program.jpg" alt="alternative">
                            </div> <!-- end of image-container-small -->
                        </div> <!-- end of col -->
                    </div> <!-- end of row -->
                </div> <!-- end of text-container -->

                <div class="text-container dark">
                    <p class="testimonial-text">At Bright Horizon Inc., we envision a world where individuals with developmental/learning disabilities and mental illness thrive in a supportive and nurturing environment, unlocking their full potential and leading fulfilling lives. Our commitment is to be a beacon of hope, fostering inclusive communities that empower every individual to overcome challenges and embrace a future filled with possibilities.</p>
                </div> <!-- end of text container -->

                <div class="text-container last">
                    <h3>Mission statement</h3>
                    <p>Bright Horizon Inc. is dedicated to providing exceptional care and support for children and adults with developmental/learning disabilities and mental illness within a residential setting. Our mission is to create a compassionate and enriching living environment that promotes independence, self-discovery, and overall well-being.</p>
                </div> <!-- end of text-container -->
                <a class="btn-outline-reg" href="index.php">BACK</a>
            </div> <!-- end of col-->
        </div> <!-- end of row -->
    </div> <!-- end of container -->
</div> <!-- end of ex-basic-2 -->
<!-- end of privacy content -->


<!-- Breadcrumbs -->
<div class="ex-basic-1">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="breadcrumbs">
                    <a href="index.php">Home</a><i class="fa fa-angle-double-right"></i><span>Bright Horizons Inc.</span>
                </div> <!-- end of breadcrumbs -->
            </div> <!-- end of col -->
        </div> <!-- end of row -->
    </div> <!-- end of container -->
</div> <!-- end of ex-basic-1 -->
<!-- end of breadcrumbs -->

<?php
    include 'inc/footer.php';
?>
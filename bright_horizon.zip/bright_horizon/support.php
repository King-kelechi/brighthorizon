<?php
include 'inc/header.php';
?>
 
 <!-- Header -->
 <header id="header" class="ex-header">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1>Intensive Supported Living Program</h1>
            </div> <!-- end of col -->
        </div> <!-- end of row -->
    </div> <!-- end of container -->
</header> <!-- end of ex-header -->
<!-- end of header -->


<!-- Breadcrumbs -->
<div class="ex-basic-1">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="breadcrumbs">
                    <a href="index.php">Home</a><i class="fa fa-angle-double-right"></i><span>Intensive Supported Living Program</span>
                </div> <!-- end of breadcrumbs -->
            </div> <!-- end of col -->
        </div> <!-- end of row -->
    </div> <!-- end of container -->
</div> <!-- end of ex-basic-1 -->
<!-- end of breadcrumbs -->


<!-- Privacy Content -->
<div class="ex-basic-2">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="image-container-large">
                    <img class="img-fluid" src="images/talk.jpeg" alt="alternative">
                </div> <!-- end of image-container-large -->
                <div class="text-container">
                    <h3>Intensive Supported Living Program</h3>
                    <p>Discover a transformative living experience through Bright Horizons Inc.'s Intensive Supported Living Program. Designed for children and adults facing developmental, learning disabilities, and mental health challenges, our program goes beyond traditional residential care. With a dedicated team of caregivers, personalized therapeutic interventions, and a commitment to life skills development, we create a dynamic and empowering environment that fosters independence, resilience, and a life filled with purpose.</p>
                    <p>Register with us and enjoy an amazing relationship <a class="blue" href="apply.php">Intensive Supported Living Program</a> to get more information:</p>
                    <div class="row">
                        
                    </div> <!-- end of row -->
                </div> <!-- end of text-container-->
                
                <div class="text-container">
                    <div class="row">
                        <div class="col-md-6">
                            <h3>Intensive Supported Living Program</h3>
                            <p>Our Intensive Supported Living Program is a testament to the belief that every individual deserves a space where their unique strengths are celebrated, and their journey towards independence is championed. Here, our dedicated team of caregivers doesn't just provide assistance; they become mentors, advocates, and allies on the path to personal triumph.

                                Within the walls of Bright Horizons Inc.'s Intensive Supported Living homes, we seamlessly blend expertise with empathy, creating a tapestry of care that is as individualized as the people we serve. From personalized therapeutic interventions to life skills development, we pave the way for not just survival but for a life of purpose and fulfillment.
                            </p>
                           
                        </div> <!-- end of col -->
                        <div class="col-md-6">
                            <div class="image-container-small">
                                <img class="img-fluid" src='images/intensive_living.jpeg' alt="alternative">
                            </div> <!-- end of image-container-small -->
                            <br><br>
                            <span class="nav-item">
                                <a class="btn-outline-sm" href="apply.php">Register Here with Us</a>
                            </span>
                        </div> <!-- end of col -->
                    </div> <!-- end of row -->
                </div> <!-- end of text-container -->

                <div class="text-container dark">
                    <p class="testimonial-text">At Bright Horizon Inc., we envision a world where individuals with developmental/learning disabilities and mental illness thrive in a supportive and nurturing environment, unlocking their full potential and leading fulfilling lives. Our commitment is to be a beacon of hope, fostering inclusive communities that empower every individual to overcome challenges and embrace a future filled with possibilities.</p>
                </div> <!-- end of text container -->

                
            </div> <!-- end of col-->
        </div> <!-- end of row -->
    </div> <!-- end of container -->
</div> <!-- end of ex-basic-2 -->
<!-- end of privacy content -->


<!-- Breadcrumbs -->
<div class="ex-basic-1">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="breadcrumbs">
                    <a href="index.php">Home</a><i class="fa fa-angle-double-right"></i><span>Intensive Supported Living Program</span>
                </div> <!-- end of breadcrumbs -->
            </div> <!-- end of col -->
        </div> <!-- end of row -->
    </div> <!-- end of container -->
</div> <!-- end of ex-basic-1 -->
<!-- end of breadcrumbs -->

<?php
    include 'inc/footer.php';
?>
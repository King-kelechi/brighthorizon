<?php
include 'inc/header.php';
?>
 
 <!-- Header -->
 <header id="header" class="ex-header">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1>Specialized Foster Care</h1>
            </div> <!-- end of col -->
        </div> <!-- end of row -->
    </div> <!-- end of container -->
</header> <!-- end of ex-header -->
<!-- end of header -->


<!-- Breadcrumbs -->
<div class="ex-basic-1">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="breadcrumbs">
                    <a href="index.php">Home</a><i class="fa fa-angle-double-right"></i><span>Specialized Foster Care</span>
                </div> <!-- end of breadcrumbs -->
            </div> <!-- end of col -->
        </div> <!-- end of row -->
    </div> <!-- end of container -->
</div> <!-- end of ex-basic-1 -->
<!-- end of breadcrumbs -->


<!-- Privacy Content -->
<div class="ex-basic-2">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="image-container-large">
                    <img class="img-fluid" src="images/foster-care-blog-1.png" alt="alternative">
                </div> <!-- end of image-container-large -->
                <div class="text-container">
                    <h3>Specialized Foster Care</h3>
                    <p>Embrace a unique and compassionate approach to fostering by joining Bright Horizons Inc.'s Specialized Foster Care program. We provide loving homes and dedicated caregivers for children and adults with developmental, learning disabilities, and mental illness. Our specialized foster care services focus on creating a supportive family environment, offering tailored educational and therapeutic interventions, and championing the growth and potential of every individual entrusted to our care.</p>
                    <p>Register with us and enjoy an amazing relationship <a class="blue" href="apply.php">Specialized Foster Care program</a> to get more information:</p>
                    <div class="row">
                        
                    </div> <!-- end of row -->
                </div> <!-- end of text-container-->
                
                <div class="text-container">
                    <div class="row">
                        <div class="col-md-6">
                            <h3>Specialized Foster Care</h3>
                            <p>Bright Horizons Inc.'s Specialized Foster Care is a promise of unwavering support, where we stand beside each individual as they navigate the complexities of their unique journey. Join us in creating a home that goes beyond shelter, where love, understanding, and empowerment converge to redefine what's possible for those who inspire us daily. Welcome to a place where family is more than blood; it's a shared commitment to fostering a future of boundless potential.
                            </p>
                           
                        </div> <!-- end of col -->
                        <div class="col-md-6">
                            <div class="image-container-small">
                                <img class="img-fluid" src='images/foster-care-1000x600.jpg' alt="alternative">
                            </div> <!-- end of image-container-small -->
                            <br><br>
                            <span class="nav-item">
                                <a class="btn-outline-sm" href="apply.php">Register Here with Us</a>
                            </span>
                        </div> <!-- end of col -->
                    </div> <!-- end of row -->
                </div> <!-- end of text-container -->

                <div class="text-container dark">
                    <p class="testimonial-text">At Bright Horizon Inc., we envision a world where individuals with developmental/learning disabilities and mental illness thrive in a supportive and nurturing environment, unlocking their full potential and leading fulfilling lives. Our commitment is to be a beacon of hope, fostering inclusive communities that empower every individual to overcome challenges and embrace a future filled with possibilities.</p>
                </div> <!-- end of text container -->

                
            </div> <!-- end of col-->
        </div> <!-- end of row -->
    </div> <!-- end of container -->
</div> <!-- end of ex-basic-2 -->
<!-- end of privacy content -->


<!-- Breadcrumbs -->
<div class="ex-basic-1">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="breadcrumbs">
                    <a href="index.php">Home</a><i class="fa fa-angle-double-right"></i><span>Specialized Foster Care</span>
                </div> <!-- end of breadcrumbs -->
            </div> <!-- end of col -->
        </div> <!-- end of row -->
    </div> <!-- end of container -->
</div> <!-- end of ex-basic-1 -->
<!-- end of breadcrumbs -->

<?php
    include 'inc/footer.php';
?>